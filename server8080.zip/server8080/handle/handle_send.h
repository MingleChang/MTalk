//
//  handle_send.h
//  server
//
//  Created by Mingle on 2018/3/15.
//  Copyright © 2018年 Mingle. All rights reserved.
//

#ifndef handle_send_h
#define handle_send_h

#include <stdio.h>
#include "base_socket.h"

int handleSend(struct base_socket *socket);

#endif /* handle_send_h */
