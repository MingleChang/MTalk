//
//  handle_user_list.h
//  server
//
//  Created by Mingle on 2018/3/15.
//  Copyright © 2018年 Mingle. All rights reserved.
//

#ifndef handle_user_list_h
#define handle_user_list_h

#include <stdio.h>
#include "base_socket.h"

int handleUserList(struct base_socket *socket);

#endif /* handle_user_list_h */
