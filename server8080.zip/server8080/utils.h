//
//  utils.h
//  server
//
//  Created by Mingle on 2018/3/9.
//  Copyright © 2018年 Mingle. All rights reserved.
//

#ifndef utils_h
#define utils_h

#include <stdio.h>

char *Create_uuid(void);
void Set_non_block(int fd);
void Set_no_delay(int fd);

#endif /* utils_h */
