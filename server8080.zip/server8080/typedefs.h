#ifndef _UINT32_T
#define _UINT32_T
typedef unsigned int uint32_t;
#endif

#ifndef _UINT16_T
#define _UINT16_T
typedef unsigned short uint16_t;
#endif 

#ifndef _UINT8_T
#define _UINT8_T
typedef unsigned char uint8_t;
#endif