//
//  register_response.h
//  server
//
//  Created by Mingle on 2018/3/15.
//  Copyright © 2018年 Mingle. All rights reserved.
//

#ifndef register_response_h
#define register_response_h

#include <stdio.h>

#endif /* register_response_h */
